/* -*- Mode: H; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * about.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include <gtkmm/aboutdialog.h>
#include "iabout.h"

namespace Electux::App::View::About
{
    class AppAbout : public Gtk::AboutDialog, public virtual IAboutView
    {
    public:
        //////////////////////////////////////////////////////////////////////
        /// @brief AppAbout constructor
        explicit AppAbout();

        //////////////////////////////////////////////////////////////////////
        /// @brief AppAbout destructor
        ~AppAbout() noexcept override = default;

        //////////////////////////////////////////////////////////////////////
        /// @brief Shows the dialog
        void show() override;

        //////////////////////////////////////////////////////////////////////
        /// @brief Hides the dialog
        void hide() override;

        //////////////////////////////////////////////////////////////////////
        /// @brief Presents the dialog
        void present() override;

        //////////////////////////////////////////////////////////////////////
        /// @brief Gets underlying Gtk::Window reference
        /// @return Reference to this Gtk::Window
        Gtk::Window& get_window() override;
    };
}
