/* -*- Mode: CC; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * about.cc
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#include "about.h"

namespace
{
    constexpr const char* PROGRAM_NAME = "${PRO}";
    constexpr const char* VERSION = "1.0.0";
    constexpr const char* COPYRIGHT = "Vladimir Roncevic <elektron.ronca@gmail.com>";
    constexpr const char* COMMENTS = "This is ${PRO} application.";
    constexpr const char* LICENSE = "GPLv3";
    constexpr const char* WEBSITE = "https://electux.github.io/${PRO}";
    constexpr const char* WEBSITE_LABEL = "electux.github.io/${PRO}";
    constexpr const char* AUTHOR_NAME = "Vladimir Roncevic";
    constexpr bool HIDE_ON_CLOSE = true;
}

using namespace Electux::App::View::About;

AppAbout::AppAbout()
{
    set_program_name(PROGRAM_NAME);
    set_version(VERSION);
    set_copyright(COPYRIGHT);
    set_comments(COMMENTS);
    set_license(LICENSE);
    set_website(WEBSITE);
    set_website_label(WEBSITE_LABEL);
    std::vector<Glib::ustring> list_authors;
    list_authors.push_back(AUTHOR_NAME);
    set_authors(list_authors);
    set_hide_on_close(HIDE_ON_CLOSE);
}

void AppAbout::show()
{
    set_visible(true);
}

void AppAbout::hide()
{
    set_visible(false);
}

void AppAbout::present()
{
    Gtk::AboutDialog::present();
}

Gtk::Window& AppAbout::get_window()
{
    return *this;
}
