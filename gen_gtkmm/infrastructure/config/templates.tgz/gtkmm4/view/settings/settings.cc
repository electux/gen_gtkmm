/* -*- Mode: CC; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * settings.cc
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#include "settings.h"

namespace
{
    constexpr const char* WINDOW_TITLE = "${PRO}";
    constexpr int DEFAULT_WIDTH = 600;
    constexpr int DEFAULT_HEIGHT = 300;
    constexpr bool IS_RESIZABLE = false;
    constexpr bool HIDE_ON_CLOSE = true;

    constexpr int CONTENT_WIDTH = 380;
    constexpr int CONTENT_HEIGHT = 240;
    constexpr int BUTTON_BOX_WIDTH = 220;
    constexpr int BUTTON_BOX_HEIGHT = 60;
    constexpr int BUTTON_WIDTH = 100;
    constexpr int BUTTON_HEIGHT = 50;
    constexpr int BOX_SPACING = 5;

    constexpr const char* LABEL_OK = "Ok";
    constexpr const char* LABEL_CANCEL = "Cancel";
}

using namespace Electux::App::View::Settings;

AppSettings::AppSettings(std::shared_ptr<Model::IModel> model):
    m_model(std::move(model))
{
    set_title(WINDOW_TITLE);
    set_default_size(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    set_resizable(IS_RESIZABLE);
    set_hide_on_close(HIDE_ON_CLOSE);
    set_child(m_vbox);
    m_content_box.set_size_request(CONTENT_WIDTH, CONTENT_HEIGHT);
    m_vbox.append(m_content_box);
    m_button_box.set_size_request(BUTTON_BOX_WIDTH, BUTTON_BOX_HEIGHT);
    m_button_ok.set_label(LABEL_OK);
    m_button_ok.set_size_request(BUTTON_WIDTH, BUTTON_HEIGHT);
    m_button_cancel.set_label(LABEL_CANCEL);
    m_button_cancel.set_size_request(BUTTON_WIDTH, BUTTON_HEIGHT);
    m_button_box.attach(m_button_ok, 0, 0, 1, 1);
    m_button_box.attach(m_button_cancel, 1, 0, 1, 1);
    m_button_box.set_hexpand(false);
    m_button_box.set_vexpand(false);
    m_button_box.set_row_spacing(BOX_SPACING);
    m_button_box.set_column_spacing(BOX_SPACING);
    m_vbox.append(m_button_box);

    //////////////////////////////////////////////////////////////////////////
    /// Connect the signal handlers to the buttons
    m_button_ok.signal_clicked().connect(
        sigc::mem_fun(*this, &AppSettings::on_button_ok_clicked)
    );
    m_button_cancel.signal_clicked().connect(
        sigc::mem_fun(*this, &AppSettings::on_button_cancel_clicked)
    );
}

void AppSettings::show()
{
    set_visible(true);
}

void AppSettings::hide()
{
    set_visible(false);
}

void AppSettings::present()
{
    Gtk::Window::present();
}

Gtk::Window& AppSettings::get_window()
{
    return *this;
}

void AppSettings::on_button_ok_clicked()
{
    //////////////////////////////////////////////////////////////////////////
    /// Perform action on OK button
    hide();
}

void AppSettings::on_button_cancel_clicked()
{
    //////////////////////////////////////////////////////////////////////////
    /// Perform action on Cancel button
    hide();
}
