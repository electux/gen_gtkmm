/* -*- Mode: CC; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * application.cc
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#include "application.h"
#include <glibmm/miscutils.h>
#include <glibmm/refptr.h>

namespace
{
    constexpr const char* APP_ID = "electux.io.${PRO}";

    constexpr const char* ACTION_QUIT = "quit";
    constexpr const char* ACTION_SETTINGS = "setting";
    constexpr const char* ACTION_DOC = "doc";
    constexpr const char* ACTION_ABOUT = "about";

    constexpr const char* ACCEL_QUIT = "<Primary>q";
    constexpr const char* ACTION_TARGET_QUIT = "app.quit";
    constexpr const char* ACTION_TARGET_SETTINGS = "app.setting";
    constexpr const char* ACTION_TARGET_DOC = "app.doc";
    constexpr const char* ACTION_TARGET_ABOUT = "app.about";

    constexpr const char* MENU_LABEL_FILE = "File";
    constexpr const char* MENU_LABEL_QUIT = "_Quit";
    constexpr const char* MENU_LABEL_OPTION = "Option";
    constexpr const char* MENU_LABEL_SETTINGS = "_Settings";
    constexpr const char* MENU_LABEL_HELP = "Help";
    constexpr const char* MENU_LABEL_DOC = "_Documentation";
    constexpr const char* MENU_LABEL_ABOUT = "_About";
}

using namespace Electux::App;

EntryApplication::EntryApplication(std::shared_ptr<Factory::IFactory> factory):
    Gtk::Application(APP_ID),
    m_factory(std::move(factory))
{
    Glib::set_application_name(APP_ID);
}

Glib::RefPtr<EntryApplication> EntryApplication::create(
    std::shared_ptr<Factory::IFactory> factory
)
{
    return Glib::make_refptr_for_instance<EntryApplication>(
        new EntryApplication(std::move(factory))
    );
}

void EntryApplication::on_startup()
{
    Gtk::Application::on_startup();

    //////////////////////////////////////////////////////////////////////////
    /// Sets application menubar
    auto menu = Gio::Menu::create();
    auto submenu_file = Gio::Menu::create();
    submenu_file->append(MENU_LABEL_QUIT, ACTION_TARGET_QUIT);
    menu->append_submenu(MENU_LABEL_FILE, submenu_file);
    auto submenu_option = Gio::Menu::create();
    submenu_option->append(MENU_LABEL_SETTINGS, ACTION_TARGET_SETTINGS);
    menu->append_submenu(MENU_LABEL_OPTION, submenu_option);
    auto submenu_help = Gio::Menu::create();
    submenu_help->append(MENU_LABEL_DOC, ACTION_TARGET_DOC);
    submenu_help->append(MENU_LABEL_ABOUT, ACTION_TARGET_ABOUT);
    menu->append_submenu(MENU_LABEL_HELP, submenu_help);
    set_menubar(menu);

    //////////////////////////////////////////////////////////////////////////
    /// Sets a keyboard accelerator that will trigger application quit
    set_accel_for_action(ACTION_TARGET_QUIT, ACCEL_QUIT);

    //////////////////////////////////////////////////////////////////////////
    /// Sets application actions
    add_action(
        ACTION_QUIT, sigc::mem_fun(*this, &EntryApplication::on_action_quit)
    );
    add_action(
        ACTION_SETTINGS, sigc::mem_fun(*this, &EntryApplication::on_action_settings)
    );
    add_action(
        ACTION_DOC, sigc::mem_fun(*this, &EntryApplication::on_action_doc)
    );
    add_action(
        ACTION_ABOUT, sigc::mem_fun(*this, &EntryApplication::on_action_about)
    );

    //////////////////////////////////////////////////////////////////////////
    /// Instantiate model and views exclusively via Factory
    if (m_factory)
    {
        m_model = m_factory->create_model();
        m_home = m_factory->create_home_view(m_model);
        m_settings = m_factory->create_settings_view(m_model);
        m_help = m_factory->create_help_view();
        m_about = m_factory->create_about_view();
    }

    //////////////////////////////////////////////////////////////////////////
    /// Sets AppHome as toplevel window, add to the application window
    if (m_home)
    {
        add_window(m_home->get_window());
        m_home->present();
    }
}

void EntryApplication::on_action_quit()
{
    if (m_home)
    {
        m_home->hide();
        remove_window(m_home->get_window());
    }
    quit();
}

void EntryApplication::on_action_settings()
{
    if (m_settings)
    {
        m_settings->present();
    }
}

void EntryApplication::on_action_doc()
{
    if (m_help)
    {
        m_help->present();
    }
}

void EntryApplication::on_action_about()
{
    if (m_about)
    {
        m_about->present();
    }
}
