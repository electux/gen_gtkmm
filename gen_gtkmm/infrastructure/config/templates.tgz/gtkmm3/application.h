/* -*- Mode: H; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * application.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include <memory>
#include <gtkmm/application.h>
#include "factory/ifactory.h"
#include "model/imodel.h"
#include "view/ihome.h"
#include "view/settings/isettings.h"
#include "view/help/ihelp.h"
#include "view/about/iabout.h"

namespace Electux::App
{
    //////////////////////////////////////////////////////////////////////////
    /// @brief Entry point for application
    class EntryApplication : public Gtk::Application
    {
    public:
        //////////////////////////////////////////////////////////////////////
        /// @brief EntryApplication constructor
        /// @param factory Shared pointer to component factory interface
        explicit EntryApplication(std::shared_ptr<Factory::IFactory> factory);

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates reference pointer to EntryApplication
        /// @param factory Shared pointer to component factory interface
        static Glib::RefPtr<EntryApplication> create(
            std::shared_ptr<Factory::IFactory> factory
        );

    protected:
        //////////////////////////////////////////////////////////////////////
        /// @brief Handler for the startup signal
        void on_startup() override;

    private:
        //////////////////////////////////////////////////////////////////////
        /// @brief On action settings create window for application settings
        void on_action_settings();

        //////////////////////////////////////////////////////////////////////
        /// @brief On action doc create window for help documentation
        void on_action_doc();

        //////////////////////////////////////////////////////////////////////
        /// @brief On action about create dialog for about application
        void on_action_about();

        //////////////////////////////////////////////////////////////////////
        /// @brief On action for quit
        void on_action_quit();

        //////////////////////////////////////////////////////////////////////
        /// @brief Component factory interface
        std::shared_ptr<Factory::IFactory> m_factory;

        //////////////////////////////////////////////////////////////////////
        /// @brief Data model interface
        std::shared_ptr<Model::IModel> m_model;

        //////////////////////////////////////////////////////////////////////
        /// @brief Interface for HomeView (main window)
        std::unique_ptr<View::IHomeView> m_home;

        //////////////////////////////////////////////////////////////////////
        /// @brief Interface for AppSettings (settings window)
        std::unique_ptr<View::Settings::ISettingsView> m_settings;

        //////////////////////////////////////////////////////////////////////
        /// @brief Interface for AppHelp (help window)
        std::unique_ptr<View::Help::IHelpView> m_help;

        //////////////////////////////////////////////////////////////////////
        /// @brief Interface for AppAbout (about dialog)
        std::unique_ptr<View::About::IAboutView> m_about;
    };
}
