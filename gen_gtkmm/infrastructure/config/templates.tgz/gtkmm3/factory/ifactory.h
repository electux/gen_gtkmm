/* -*- Mode: H; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * ifactory.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include <memory>
#include <glibmm/refptr.h>
#include <gtkmm/application.h>

namespace Electux::App::Model
{
    class IModel;
}

namespace Electux::App::View
{
    class IHomeView;
}

namespace Electux::App::View::Settings
{
    class ISettingsView;
}

namespace Electux::App::View::Help
{
    class IHelpView;
}

namespace Electux::App::View::About
{
    class IAboutView;
}

namespace Electux::App::Factory
{
    //////////////////////////////////////////////////////////////////////////
    /// @brief Abstract factory interface for creating application components
    class IFactory
    {
    public:
        //////////////////////////////////////////////////////////////////////
        /// @brief IFactory virtual destructor
        virtual ~IFactory() noexcept = default;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the main application instance
        /// @return RefPtr to Gtk::Application
        virtual Glib::RefPtr<Gtk::Application> create_application() = 0;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the model instance
        /// @return Shared pointer to IModel
        virtual std::shared_ptr<Model::IModel> create_model() = 0;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the home view
        /// @param model Shared pointer to IModel
        /// @return Unique pointer to IHomeView
        virtual std::unique_ptr<View::IHomeView> create_home_view(
            std::shared_ptr<Model::IModel> model
        ) = 0;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the settings view
        /// @param model Shared pointer to IModel
        /// @return Unique pointer to ISettingsView
        virtual std::unique_ptr<View::Settings::ISettingsView> create_settings_view(
            std::shared_ptr<Model::IModel> model
        ) = 0;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the help view
        /// @return Unique pointer to IHelpView
        virtual std::unique_ptr<View::Help::IHelpView> create_help_view() = 0;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the about view
        /// @return Unique pointer to IAboutView
        virtual std::unique_ptr<View::About::IAboutView> create_about_view() = 0;
    };
}
