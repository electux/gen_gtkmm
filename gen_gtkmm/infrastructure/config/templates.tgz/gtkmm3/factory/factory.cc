/* -*- Mode: CC; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * factory.cc
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#include "factory.h"
#include "../application.h"
#include "../model/model.h"
#include "../view/home.h"
#include "../view/settings/settings.h"
#include "../view/help/help.h"
#include "../view/about/about.h"

using namespace Electux::App::Factory;

Glib::RefPtr<Gtk::Application> AppFactory::create_application()
{
    return EntryApplication::create(shared_from_this());
}

std::shared_ptr<Electux::App::Model::IModel> AppFactory::create_model()
{
    return std::make_shared<Model::Model>();
}

std::unique_ptr<Electux::App::View::IHomeView> AppFactory::create_home_view(
    std::shared_ptr<Model::IModel> model
)
{
    return std::make_unique<View::AppHome>(std::move(model));
}

std::unique_ptr<Electux::App::View::Settings::ISettingsView> AppFactory::create_settings_view(
    std::shared_ptr<Model::IModel> model
)
{
    return std::make_unique<View::Settings::AppSettings>(std::move(model));
}

std::unique_ptr<Electux::App::View::Help::IHelpView> AppFactory::create_help_view()
{
    return std::make_unique<View::Help::AppHelp>();
}

std::unique_ptr<Electux::App::View::About::IAboutView> AppFactory::create_about_view()
{
    return std::make_unique<View::About::AppAbout>();
}
