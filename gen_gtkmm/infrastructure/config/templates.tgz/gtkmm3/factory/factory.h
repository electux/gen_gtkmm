/* -*- Mode: H; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * factory.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include <memory>
#include "ifactory.h"

namespace Electux::App::Factory
{
    //////////////////////////////////////////////////////////////////////////
    /// @brief Concrete factory for creating application components
    class AppFactory : public IFactory, public std::enable_shared_from_this<AppFactory>
    {
    public:
        //////////////////////////////////////////////////////////////////////
        /// @brief AppFactory constructor
        explicit AppFactory() = default;

        //////////////////////////////////////////////////////////////////////
        /// @brief AppFactory destructor
        ~AppFactory() noexcept override = default;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the main application instance
        /// @return RefPtr to Gtk::Application
        Glib::RefPtr<Gtk::Application> create_application() override;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the model instance
        /// @return Shared pointer to IModel
        std::shared_ptr<Model::IModel> create_model() override;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the home view
        /// @param model Shared pointer to IModel
        /// @return Unique pointer to IHomeView
        std::unique_ptr<View::IHomeView> create_home_view(
            std::shared_ptr<Model::IModel> model
        ) override;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the settings view
        /// @param model Shared pointer to IModel
        /// @return Unique pointer to ISettingsView
        std::unique_ptr<View::Settings::ISettingsView> create_settings_view(
            std::shared_ptr<Model::IModel> model
        ) override;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the help view
        /// @return Unique pointer to IHelpView
        std::unique_ptr<View::Help::IHelpView> create_help_view() override;

        //////////////////////////////////////////////////////////////////////
        /// @brief Creates the about view
        /// @return Unique pointer to IAboutView
        std::unique_ptr<View::About::IAboutView> create_about_view() override;
    };
}
