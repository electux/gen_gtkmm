/* -*- Mode: H; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * iwindow.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include <gtkmm/window.h>

namespace Electux::App::View
{
    //////////////////////////////////////////////////////////////////////////
    /// @brief Abstract window interface for top-level windows
    class IWindow
    {
    public:
        //////////////////////////////////////////////////////////////////////
        /// @brief IWindow virtual destructor
        virtual ~IWindow() noexcept = default;

        //////////////////////////////////////////////////////////////////////
        /// @brief Shows the window
        virtual void show() = 0;

        //////////////////////////////////////////////////////////////////////
        /// @brief Hides the window
        virtual void hide() = 0;

        //////////////////////////////////////////////////////////////////////
        /// @brief Presents the window to the user
        virtual void present() = 0;

        //////////////////////////////////////////////////////////////////////
        /// @brief Gets underlying Gtk::Window reference
        /// @return Reference to Gtk::Window
        virtual Gtk::Window& get_window() = 0;
    };
}
