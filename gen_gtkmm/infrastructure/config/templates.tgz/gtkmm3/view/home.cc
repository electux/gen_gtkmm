/* -*- Mode: CC; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * home.cc
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#include "home.h"

namespace
{
    constexpr const char* WINDOW_TITLE = "${PRO}";
    constexpr int DEFAULT_WIDTH = 800;
    constexpr int DEFAULT_HEIGHT = 480;
    constexpr bool IS_RESIZABLE = false;
    constexpr bool SHOW_MENUBAR = true;
}

using namespace Electux::App::View;

AppHome::AppHome(std::shared_ptr<Model::IModel> model):
    m_model(std::move(model))
{
    set_title(WINDOW_TITLE);
    set_default_size(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    set_resizable(IS_RESIZABLE);
    set_show_menubar(SHOW_MENUBAR);
    add(m_box);
    show_all_children();
}

void AppHome::show()
{
    Gtk::ApplicationWindow::show_all();
}

void AppHome::hide()
{
    Gtk::ApplicationWindow::hide();
}

void AppHome::present()
{
    Gtk::ApplicationWindow::present();
}

Gtk::Window& AppHome::get_window()
{
    return *this;
}
