/* -*- Mode: CC; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * help.cc
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#include "help.h"

namespace
{
    constexpr const char* WINDOW_TITLE = "${PRO}";
    constexpr int DEFAULT_WIDTH = 600;
    constexpr int DEFAULT_HEIGHT = 400;
    constexpr bool IS_RESIZABLE = false;
}

using namespace Electux::App::View::Help;

AppHelp::AppHelp()
{
    set_title(WINDOW_TITLE);
    set_default_size(DEFAULT_WIDTH, DEFAULT_HEIGHT);
    set_resizable(IS_RESIZABLE);

    //////////////////////////////////////////////////////////////////////////
    /// Connect the signal handler for delete event (replace close with hide)
    signal_delete_event().connect(
        sigc::mem_fun(*this, &AppHelp::on_delete_event)
    );
}

void AppHelp::show()
{
    Gtk::Window::show_all();
}

void AppHelp::hide()
{
    Gtk::Window::hide();
}

void AppHelp::present()
{
    Gtk::Window::present();
}

Gtk::Window& AppHelp::get_window()
{
    return *this;
}

bool AppHelp::on_delete_event(GdkEventAny* /*any_event*/)
{
    hide();
    return true;
}
