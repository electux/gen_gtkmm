/* -*- Mode: H; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * ihelp.h
 * Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
 *
 * ${PRO} is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ${PRO} is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include "../iwindow.h"

namespace Electux::App::View::Help
{
    //////////////////////////////////////////////////////////////////////////
    /// @brief Abstract interface for the application help window
    class IHelpView : public virtual IWindow
    {
    public:
        //////////////////////////////////////////////////////////////////////
        /// @brief IHelpView virtual destructor
        virtual ~IHelpView() noexcept override = default;
    };
}
